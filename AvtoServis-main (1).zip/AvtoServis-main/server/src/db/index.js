const { pool, query, transaction, statement, toPgPlaceholders } = require('./pool');

const { DEFAULT_SETTINGS, DEFAULT_MASTER_PERMISSIONS } = require('./defaults');

/**
 * Query facade.
 *
 * Call sites keep the familiar `db.prepare(sql).get(...)` shape so route code
 * stays readable; the methods are async because PostgreSQL has no synchronous API.
 * `?` placeholders are rewritten to `$n` automatically.
 *
 * SQLite-isms deliberately NOT emulated (they are ported properly instead):
 *   - `last_insert_rowid()`  -> `.one()` with `RETURNING id`
 *   - `INSERT OR REPLACE`    -> `INSERT ... ON CONFLICT ... DO UPDATE`
 *   - `datetime('now')`      -> `app_now()` (migrations/001_init.sql)
 *   - `BEGIN`/`COMMIT`       -> `db.transaction(async (t) => { ... })`
 */

// Opt-in statement counter (DB_TRACE_QUERIES=1) used by the N+1 regression test.
const stats = { count: 0, enabled: process.env.DB_TRACE_QUERIES === '1' };

function flatten(params) {
  if (params.length === 1 && Array.isArray(params[0])) return params[0];
  return params;
}

function prepare(sql) {
  if (stats.enabled) stats.count++;
  const stmt = statement((text, params) => query(text, params), toPgPlaceholders(sql));
  // Accept both `stmt.get(a, b)` and `stmt.get([a, b])` so call sites can pass
  // spread params or a ready-made array.
  const wrap = (fn) => async (...params) => fn(flatten(params));
  return {
    sql: stmt.sql,
    get: wrap(stmt.get),
    all: wrap(stmt.all),
    run: wrap(stmt.run),
    /** For INSERT/UPDATE/DELETE ... RETURNING: resolves to the first row. */
    one: wrap(stmt.one),
  };
}

/** Statement with no parameters (schema checks, diagnostics). */
function prepareRaw(sql) {
  return {
    get: async () => (await query(sql)).rows[0],
    all: async () => (await query(sql)).rows,
  };
}

const counter = {
  get: () => stats.count,
  reset: () => {
    stats.count = 0;
  },
  enabled: () => stats.enabled,
};

// Exposed on `db` so the diagnostics route can read the counter without
// importing this module's internals.
const db = {
  prepare,
  prepareRaw,
  transaction,
  query,
  pool,
  __getQueryCount: counter.get,
  __resetQueryCount: counter.reset,
  __traceEnabled: counter.enabled,
};
/**
 * Advisory lock key for seeding.
 *
 * Distinct from the migration lock so a cold start never nests the two, and so
 * seeding stays serialised even though migrations release their lock first.
 */
const SEED_LOCK_ID = 728411905518;

/**
 * Inserts the default settings and the default service catalogue.
 *
 * Safe on every cold start and safe to call concurrently: the lock makes the
 * check-then-insert below atomic per database, and the settings upsert is
 * idempotent by primary key.
 *
 * The lock is preferred over a unique index on `services(sort_order)` because
 * admins can set arbitrary sort orders, so existing production data may already
 * contain duplicates. Creating a unique index over that data would fail and
 * block startup, whereas a lock never touches existing rows.
 */
async function seed() {
  const client = await pool.connect();
  let locked = false;
  try {
    await client.query('SELECT pg_advisory_lock($1)', [String(SEED_LOCK_ID)]);
    locked = true;

    for (const key of Object.keys(DEFAULT_SETTINGS)) {
      await client.query(
        toPgPlaceholders('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT (key) DO NOTHING'),
        [key, JSON.stringify(DEFAULT_SETTINGS[key])]
      );
    }

    const { rows } = await client.query('SELECT COUNT(*) AS c FROM services');
    if (Number(rows[0].c) === 0) {
      const services = [
        ['Mator xodovoy', 'Dvigatel va xodovoy qismlarni ta\'mirlash bo\'yicha to\'liq xizmat: kapital va joriy ta\'mirlash, moy va filtrlarni almashtirish.', 'Sifatli ehtiyot qismlar|Kafolatli ta\'mirlash|Tajribali ustalar', '', 'engine', '', 1],
        ['Diagnostika', 'Komputer diagnostikasi yordamida avtomobilingizning barcha tizimlarini tekshiramiz.', 'Xatolarni aniq aniqlash|Tezkor natija|Sizga qulay vaqt', '', 'diagnostic', '', 2],
        ['Programma', 'Avtomobil tizimlarini sozlash, chip tuning va dasturiy ta\'minotni yangilash xizmatlari.', 'Quvvat oshishi|Yoqilgan\'i tejalishi|Tizim barqarorligi', '', 'chip', '', 3],
        ['Elektrik', 'Avtomobil elektr qismlarini diagnostika qilish va ta\'mirlash: starter, generator, simlar.', 'Zamonaviy uskunalar|Aniq sababni topish|Ishonchli ta\'mirlash', '', 'bolt', '', 4],
        ['Moy almashtirish', 'Dvigatel moyi va filtrlarni tez va sifatli almashtirish. Barcha turdagi moylar.', 'Moy turini tanlashda yordam|Tez xizmat|Toza ish joyi', '', 'oil', '', 5],
      ];
      for (const s of services) {
        await client.query(
          toPgPlaceholders(
            'INSERT INTO services (name, description, benefits, image, icon, price, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, 1)'
          ),
          s
        );
      }
    }
  } finally {
    if (locked) {
      await client.query('SELECT pg_advisory_unlock($1)', [String(SEED_LOCK_ID)]).catch(() => {});
    }
    client.release();
  }
}

async function resetSettings() {
  await query('DELETE FROM settings');
  await seed();
}

module.exports = { db, counter, pool, query, transaction, prepare, DEFAULT_SETTINGS, DEFAULT_MASTER_PERMISSIONS, seed, resetSettings };
